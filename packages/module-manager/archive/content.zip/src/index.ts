console.log('content script loaded');
(async () => {
  // Wait for 2 seconds
  await new Promise(resolve => setTimeout(resolve, 2000));
  // Check if `yuchi-ai-extension-signed-in-success-message` is in the document
  const signedInSuccessMessage = document.getElementById('yuchi-ai-extension-signed-in-success-message');
  if (signedInSuccessMessage) {
    // Get current tab
    const currentTab = await chrome.tabs.query({ active: true, currentWindow: true });
    if (currentTab.length > 0 && currentTab[0].id) {
      alert('Opening side panel');
      chrome.sidePanel.open({
        tabId: currentTab[0].id,
      });
    }
  }
})();
